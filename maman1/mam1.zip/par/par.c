#include "par.h" /* PrintBalanceMessage, IsTextBalance */

int main()
{
	PrintBalanceMessage(IsTextBalance());
	return 0;
}
